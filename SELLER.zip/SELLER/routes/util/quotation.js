/**
 * Created by liaokaien on 2/23/15.
 */
module.exports = function(foo) {

    foo = '\'' + foo + '\'';
    return foo;
};
